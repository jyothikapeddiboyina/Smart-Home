import streamlit as st
import pandas as pd
import joblib
import plotly.express as px
from datetime import datetime
import html

from database import (
    connect_database,
    save_prediction,
    get_predictions,
    delete_prediction
)


# =====================================================
# 1. PAGE CONFIGURATION
# =====================================================

st.set_page_config(
    page_title="SmartHome AI",
    page_icon="🏡",
    layout="wide",
    initial_sidebar_state="expanded"
)


# =====================================================
# 2. CITY-WISE LOCALITY DATA (INDICATIVE 2026 BENCHMARKS)
# =====================================================

# Approximate city averages used as the baseline for locality adjustments.
# Locality rates are indicative asking-price benchmarks in INR per sq. ft.
# They are not government circle rates or guaranteed transaction prices.

CITY_AVERAGES = {
    "Hyderabad": 8342,
    "Bangalore": 11221,
    "Chennai": 8743,
    "Mumbai": 24791,
    "Delhi": 15484
}

CITY_LOCALITY_PRICES = {
    "Hyderabad": {
        "Gachibowli": 11719,
        "Kokapet": 11393,
        "Financial District": 11481,
        "Kondapur": 9343,
        "Narsingi": 9230,
        "Kukatpally": 8828,
        "Manikonda": 8285,
        "Miyapur": 7176,
        "Bachupally": 6474,
        "Kompally": 5924,
        "LB Nagar": 6798,
        "Nagole": 6798,
        "HITEC City": 10500,
        "Madhapur": 10500,
        "Banjara Hills": 14000,
        "Jubilee Hills": 15000,
        "Nizampet": 6274,
        "Chandanagar": 6771,
        "Nallagandla": 9783,
        "Uppal": 6895,
        "Puppalaguda": 8366
    },
    "Bangalore": {
        "Electronic City": 7550,
        "K R Puram": 10319,
        "Horamavu": 7776,
        "Begur": 11294,
        "Gummanahalli": 10873,
        "JP Nagar": 11721,
        "Bommasandra": 7884,
        "Jakkur": 13351,
        "Balagere": 13954
    },
    "Chennai": {
        "Madipakkam": 8163,
        "Ambattur": 6565,
        "Madhavaram": 8718,
        "Kelambakkam": 6033,
        "Kolathur": 7693,
        "Kovilambakkam": 8074,
        "Madambakkam": 7091,
        "Chromepet": 8261,
        "Adyar": 19316
    },
    "Mumbai": {
        "Malad West": 22207,
        "Powai": 31883,
        "Andheri West": 30747,
        "Kandivali East": 24848,
        "Chembur": 26404,
        "Mulund West": 24244,
        "Bhandup West": 19077,
        "Borivali West": 24601,
        "Goregaon West": 23293,
        "Andheri East": 23553,
        "Bandra East": 47929,
        "Ghatkopar East": 25877
    },
    "Delhi": {
        "Chhattarpur": 6312,
        "Vasant Kunj": 23653,
        "Dwarka Sector 6": 16362,
        "Dwarka Sector 4": 16550,
        "Dwarka Sector 10": 16438,
        "Dwarka Sector 22": 16771,
        "Burari": 5232,
        "Paschim Vihar": 12357,
        "Patparganj": 16617,
        "Vikaspuri": 13196,
        "Janakpuri": 14705,
        "Pitampura": 27133,
        "Saket": 24000,
        "Greater Kailash": 32000
    }
}



# =====================================================
# 2A. INDIA-WIDE LOCATION DIRECTORY
# State -> City -> Localities, extracted from the supplied directory PDF.
# This is a starter directory, not an exhaustive official gazetteer.
# =====================================================

INDIA_LOCATION_DATA = {'Andhra Pradesh': {'Visakhapatnam': ['MVP Colony',
                                      'Madhurawada',
                                      'Gajuwaka',
                                      'Dwaraka Nagar',
                                      'Seethammadhara',
                                      'Akkayyapalem',
                                      'Rushikonda',
                                      'Pendurthi'],
                    'Vijayawada': ['Benz Circle',
                                   'Moghalrajpuram',
                                   'Governorpet',
                                   'Patamata',
                                   'Poranki',
                                   'Kanuru',
                                   'Auto Nagar',
                                   'Bhavanipuram'],
                    'Guntur': ['Brodipet',
                               'Arundelpet',
                               'Lakshmipuram',
                               'Pattabhipuram',
                               'Nallapadu',
                               'Gorantla'],
                    'Tirupati': ['Alipiri', 'Tiruchanoor', 'MR Palli', 'Korlagunta', 'Renigunta Road'],
                    'Nellore': ['Dargamitta', 'Magunta Layout', 'Vedayapalem', 'Balaji Nagar'],
                    'Rajamahendravaram': ['Danavaipeta', 'Morampudi', 'Lalacheruvu', 'Bommuru'],
                    'Kurnool': ['N R Peta', 'Kallur', 'Budhawarpet', 'Joharapuram'],
                    'Anantapur': ['Aravinda Nagar', 'Kamalanagar', 'Sapthagiri Circle', 'Rudrampeta'],
                    'Kadapa': ['Yerramukkapalli', 'Almaspet', 'Chinna Chowk', 'Nagarajupet'],
                    'Kakinada': ['Suryaraopeta', 'Ramanayyapeta', 'Vakalapudi', 'Jagannaickpur']},
 'Arunachal Pradesh': {'Itanagar': ['Ganga', 'Naharlagun', 'Chimpu', 'Nirjuli'],
                       'Naharlagun': ['Papu Nallah', 'Model Village', 'Borum'],
                       'Pasighat': ['Mishing', 'Rani', 'Upper Market'],
                       'Tawang': ['Old Market', 'New Market', 'Thingbu'],
                       'Ziro': ['Hapoli', 'Old Ziro', 'Hong']},
 'Assam': {'Guwahati': ['Dispur',
                        'Beltola',
                        'Six Mile',
                        'Zoo Road',
                        'GS Road',
                        'Panjabari',
                        'Maligaon',
                        'Chandmari'],
           'Dibrugarh': ['Chowkidinghee', 'Milan Nagar', 'Graham Bazar', 'Amolapatty'],
           'Silchar': ['Tarapur', 'Itkhola', 'Malugram', 'Ambicapatty'],
           'Jorhat': ['Tarajan', 'Gar-Ali', 'Choladhara', 'Baruah Chariali'],
           'Tezpur': ['Mission Chariali', 'Dekargaon', 'Mahabhairab', 'Paruwa'],
           'Tinsukia': ['Rangagora Road', 'Makum Road', 'Borguri', 'Hijuguri']},
 'Bihar': {'Patna': ['Boring Road',
                     'Kankarbagh',
                     'Bailey Road',
                     'Rajendra Nagar',
                     'Danapur',
                     'Fraser Road',
                     'Patliputra Colony'],
           'Gaya': ['AP Colony', 'Gewalbigha', 'Civil Lines', 'Rampur'],
           'Muzaffarpur': ['■■■■■■■■ (Mithanpura)', 'Kalambagh Road', 'Aghoria Bazar', 'Brahmapura'],
           'Bhagalpur': ['Adampur', 'Tilkamanjhi', 'Nathnagar', 'Barari'],
           'Darbhanga': ['Laheriasarai', 'Donar', 'Benta', 'Kathalbari'],
           'Purnia': ['Line Bazar', 'Gulabbagh', 'Madhubani', 'Khuskibagh']},
 'Chhattisgarh': {'Raipur': ['Shankar Nagar',
                             'Telibandha',
                             'Pandri',
                             'Kota',
                             'Avanti Vihar',
                             'VIP Road',
                             'Saddu'],
                  'Bhilai': ['Nehru Nagar', 'Civic Centre', 'Smriti Nagar', 'Supela', 'Risali'],
                  'Bilaspur': ['Vyapar Vihar', 'Sarkanda', 'Rajkishore Nagar', 'Mangla'],
                  'Korba': ['TP Nagar', 'Kosabadi', 'Niharika', 'Risdi'],
                  'Durg': ['Padmanabhpur', 'Ganjpara', 'Malviya Nagar', 'Station Road']},
 'Goa': {'Panaji': ['Miramar', 'Altinho', 'Campal', 'Caranzalem', 'Taleigao'],
         'Margao': ['Fatorda', 'Aquem', 'Gogol', 'Pajifond'],
         'Vasco da Gama': ['Chicalim', 'Mangor Hill', 'Sada', 'Headland Sada'],
         'Mapusa': ['Karaswada', 'Duler', 'Khorlim', 'Ansabhat'],
         'Ponda': ['Farmagudi', 'Tisk', 'Curti', 'Bandora']},
 'Gujarat': {'Ahmedabad': ['Satellite',
                           'Bopal',
                           'Vastrapur',
                           'Navrangpura',
                           'Maninagar',
                           'Prahlad Nagar',
                           'SG Highway',
                           'Thaltej',
                           'Chandkheda'],
             'Surat': ['Adajan', 'Vesu', 'Pal', 'Piplod', 'Varachha', 'Katargam', 'Althan', 'Udhna'],
             'Vadodara': ['Alkapuri', 'Gotri', 'Manjalpur', 'Karelibaug', 'Akota', 'Fatehgunj'],
             'Rajkot': ['Kalawad Road', 'University Road', 'Raiya Road', 'Gondal Road', 'Mavdi'],
             'Gandhinagar': ['Sector 1–30', 'Kudasan', 'Sargasan', 'Raysan', 'Infocity'],
             'Bhavnagar': ['Kaliyabid', 'Waghawadi Road', 'Ghogha Circle', 'Nirmal Nagar'],
             'Jamnagar': ['Patel Colony', 'Park Colony', 'Khodiyar Colony', 'Ranjit Sagar Road'],
             'Junagadh': ['Zanzarda Road', 'Kalwa Chowk', 'Joshipura', 'Talav Gate']},
 'Haryana': {'Gurugram': ['DLF Phase 1–5',
                          'Cyber City',
                          'Golf Course Road',
                          'Sohna Road',
                          'Sector 14',
                          'Sector 56',
                          'Sector 57',
                          'Palam Vihar'],
             'Faridabad': ['Sector 15',
                           'Sector 16',
                           'NIT',
                           'Greenfield Colony',
                           'Sector 21',
                           'Greater Faridabad'],
             'Panipat': ['Model Town', 'Sector 11–13', 'HUDA', 'Assandh Road'],
             'Karnal': ['Sector 6', 'Sector 7', 'Sector 13', 'Model Town', 'Kunjpura Road'],
             'Hisar': ['Model Town', 'Sector 13', 'PLA', 'Urban Estate'],
             'Ambala': ['Ambala City', 'Ambala Cantt', 'Model Town', 'Jagadhri Gate']},
 'Himachal Pradesh': {'Shimla': ['Sanjauli', 'Chotta Shimla', 'New Shimla', 'Kasumpti', 'Dhalli'],
                      'Dharamshala': ['McLeod Ganj', 'Kotwali Bazaar', 'Sidhpur', 'Yol'],
                      'Solan': ['Mall Road', 'Saproon', 'Chambaghat', 'Deonghat'],
                      'Mandi': ['Indira Market', 'Ner Chowk', 'Sauli Khad', 'Bhuili'],
                      'Kullu': ['Dhalpur', 'Akhara Bazaar', 'Bhuntar', 'Shamshi'],
                      'Baddi': ['Baddi Main Market', 'Barotiwala', 'Sai Road']},
 'Jharkhand': {'Ranchi': ['Lalpur', 'Morabadi', 'Harmu', 'Doranda', 'Kanke Road', 'Bariatu', 'Hinoo'],
               'Jamshedpur': ['Sakchi', 'Bistupur', 'Kadma', 'Sonari', 'Mango', 'Telco', 'Adityapur'],
               'Dhanbad': ['Bank More', 'Saraidhela', 'Hirapur', 'Dhaiya', 'Koyla Nagar'],
               'Bokaro': ['Sector 1–12', 'Chas', 'City Centre', 'Balidih'],
               'Deoghar': ['Baidyanathdham', 'Castairs Town', 'Bilasi', 'Barmasia']},
 'Karnataka': {'Bengaluru': ['Whitefield',
                             'Electronic City',
                             'Marathahalli',
                             'Indiranagar',
                             'Koramangala',
                             'HSR Layout',
                             'Jayanagar',
                             'JP Nagar',
                             'Hebbal',
                             'Yelahanka',
                             'Rajajinagar',
                             'Malleshwaram',
                             'Sarjapur Road',
                             'Banashankari'],
               'Mysuru': ['Kuvempunagar',
                          'Vijayanagar',
                          'Jayalakshmipuram',
                          'Gokulam',
                          'Hebbal',
                          'Saraswathipuram'],
               'Mangaluru': ['Bejai', 'Kadri', 'Kankanady', 'Hampankatta', 'Surathkal', 'Derebail'],
               'Hubballi-Dharwad': ['Vidyanagar', 'Gokul Road', 'Keshwapur', 'Deshpande Nagar', 'Navanagar'],
               'Belagavi': ['Tilakwadi', 'Shahapur', 'Hanuman Nagar', 'Camp', 'Vadgaon'],
               'Kalaburagi': ['M.S.K. Mill', 'Sedam Road', 'Brhampur', 'Super Market'],
               'Shivamogga': ['Gopi Circle', 'Sagar Road', 'Vinoba Nagar', 'Durgigudi']},
 'Kerala': {'Kochi': ['Kakkanad',
                      'Edappally',
                      'Vyttila',
                      'Fort Kochi',
                      'Panampilly Nagar',
                      'Marine Drive',
                      'Kalamassery',
                      'Aluva'],
            'Thiruvananthapuram': ['Kazhakkoottam',
                                   'Kowdiar',
                                   'Pattom',
                                   'Vazhuthacaud',
                                   'Technopark',
                                   'Sreekariyam'],
            'Kozhikode': ['Mavoor Road', 'Nadakkavu', 'Palazhi', 'Kottooli', 'West Hill', 'Beypore'],
            'Thrissur': ['Punkunnam', 'Ayyanthole', 'East Fort', 'Ollur', 'Guruvayur Road'],
            'Kollam': ['Chinnakada', 'Kadappakada', 'Kavanad', 'Asramam'],
            'Kannur': ['Thavakkara', 'Talap', 'Payyambalam', 'Thottada'],
            'Kottayam': ['Nagampadam', 'Kanjikuzhi', 'Baker Junction', 'Kumaranalloor']},
 'Madhya Pradesh': {'Indore': ['Vijay Nagar',
                               'Palasia',
                               'Nipania',
                               'Rau',
                               'Bhawarkua',
                               'AB Road',
                               'Super Corridor',
                               'Scheme 54'],
                    'Bhopal': ['MP Nagar',
                               'Arera Colony',
                               'Kolar Road',
                               'Shahpura',
                               'Hoshangabad Road',
                               'Bawadia Kalan',
                               'Ayodhya Bypass'],
                    'Jabalpur': ['Wright Town', 'Napier Town', 'Vijay Nagar', 'Gorakhpur', 'Madan Mahal'],
                    'Gwalior': ['City Centre', 'Lashkar', 'Thatipur', 'Morar', 'Govindpuri'],
                    'Ujjain': ['Freeganj', 'Nanakheda', 'Mahashweta Nagar', 'Dewas Road'],
                    'Sagar': ['Makronia', 'Civil Lines', 'Bhagwan Ganj', 'Tili']},
 'Maharashtra': {'Mumbai': ['Andheri',
                            'Bandra',
                            'Powai',
                            'Borivali',
                            'Malad',
                            'Goregaon',
                            'Dadar',
                            'Juhu',
                            'Chembur',
                            'Ghatkopar',
                            'Colaba',
                            'Worli'],
                 'Pune': ['Hinjewadi',
                          'Wakad',
                          'Baner',
                          'Kothrud',
                          'Viman Nagar',
                          'Hadapsar',
                          'Kharadi',
                          'Aundh',
                          'Pimple Saudagar',
                          'Magarpatta'],
                 'Nagpur': ['Dharampeth',
                            'Sitabuldi',
                            'Manish Nagar',
                            'Wardha Road',
                            'Sadar',
                            'Pratap Nagar'],
                 'Nashik': ['College Road',
                            'Gangapur Road',
                            'Indira Nagar',
                            'Panchavati',
                            'CIDCO',
                            'Pathardi Phata'],
                 'Thane': ['Ghodbunder Road', 'Majiwada', 'Naupada', 'Hiranandani Estate', 'Wagle Estate'],
                 'Navi Mumbai': ['Vashi', 'Nerul', 'Belapur', 'Kharghar', 'Airoli', 'Panvel', 'Seawoods'],
                 'Chhatrapati Sambhajinagar': ['CIDCO',
                                               'Osmanpura',
                                               'Garkheda',
                                               'Satara Parisar',
                                               'N- en area'],
                 'Kolhapur': ['Rajarampuri', 'Tarabai Park', 'Shahupuri', 'Nagala Park']},
 'Manipur': {'Imphal': ['Thangmeiband', 'Lamphel', 'Singjamei', 'Porompat', 'Uripok'],
             'Thoubal': ['Thoubal Bazar', 'Yairipok', 'Lilong'],
             'Churachandpur': ['New Lamka', 'Tuibuong', 'Hiangtam Lamka']},
 'Meghalaya': {'Shillong': ['Laitumkhrah', 'Police Bazaar', 'Nongthymmai', 'Mawlai', 'Lachumiere', 'Polo'],
               'Tura': ['Araimile', 'Chandmari', 'Hawakhana', 'Dobasipara'],
               'Jowai': ['Iawmusiang', 'Ladthadlaboh', 'Panaliar']},
 'Mizoram': {'Aizawl': ['Chaltlang', 'Bawngkawn', 'Dawrpui', 'Tuikual', 'Zemabawk', 'Durtlang'],
             'Lunglei': ['Zobawk', 'Electric Veng', 'Ramthar Veng'],
             'Champhai': ['Vengthlang', 'Zotlang', 'Chhungte']},
 'Nagaland': {'Kohima': ['High School Junction', 'PR Hill', 'New Market', 'P.R. Hill', 'PWD Colony'],
              'Dimapur': ['Circular Road', 'Duncan Bosti', 'Burma Camp', 'Signal Angami', 'Chumoukedima'],
              'Mokokchung': ['Town Centre', 'Alempang', 'Majakong']},
 'Odisha': {'Bhubaneswar': ['Patia',
                            'Chandrasekharpur',
                            'Khandagiri',
                            'Jaydev Vihar',
                            'Saheed Nagar',
                            'Rasulgarh',
                            'Old Town',
                            'Nayapalli'],
            'Cuttack': ['CDA', 'Badambadi', 'Mangalabag', 'College Square', 'Tulsipur', 'Jagatpur'],
            'Rourkela': ['Civil Township', 'Chhend Colony', 'Udit Nagar', 'Koel Nagar', 'Sector 19'],
            'Puri': ['Grand Road', 'Baliapanda', 'Chakratirtha Road', 'Sea Beach'],
            'Sambalpur': ['Ainthapali', 'Budharaja', 'Khetrajpur', 'Modipara']},
 'Punjab': {'Ludhiana': ['Sarabha Nagar',
                         'Model Town',
                         'Pakhowal Road',
                         'Dugri',
                         'Civil Lines',
                         'Ferozepur Road'],
            'Amritsar': ['Ranjit Avenue', 'Lawrence Road', 'Green Avenue', 'Majitha Road', 'Mall Road'],
            'Jalandhar': ['Model Town', 'Urban Estate', 'GT Road', 'BMC Chowk', 'Rama Mandi'],
            'Patiala': ['Leela Bhawan', 'Model Town', 'Urban Estate', 'Tripuri'],
            'Bathinda': ['Model Town', 'Civil Lines', 'Ajit Road', 'Goniana Road'],
            'Mohali': ['Phase 3B2', 'Phase 7', 'Sector 70', 'Aerocity', 'Kharar Road']},
 'Rajasthan': {'Jaipur': ['Malviya Nagar',
                          'Vaishali Nagar',
                          'Mansarovar',
                          'C-Scheme',
                          'Jagatpura',
                          'Tonk Road',
                          'Raja Park',
                          'Civil Lines'],
               'Jodhpur': ['Sardarpura', 'Ratanada', 'Paota', 'Shastri Nagar', 'Chopasni Road'],
               'Udaipur': ['Hiran Magri', 'Fatehpura', 'Panchwati', 'Sukher', 'Bhuwana', 'Pratap Nagar'],
               'Kota': ['Talwandi', 'Mahaveer Nagar', 'Vigyan Nagar', 'Dadabari', 'Kunhari'],
               'Ajmer': ['Vaishali Nagar', 'Panchsheel Nagar', 'Civil Lines', 'Adarsh Nagar'],
               'Bikaner': ['Rani Bazar', 'Sardul Ganj', 'JNV Colony', 'Gangashahar']},
 'Sikkim': {'Gangtok': ['Deorali', 'Tadong', 'Development Area', 'Arithang', 'Upper Sichey'],
            'Namchi': ['Central Park', 'Boomtar', 'Assangthang'],
            'Geyzing': ['Upper Geyzing', 'Lower Geyzing', 'Kyongsa']},
 'Tamil Nadu': {'Chennai': ['Anna Nagar',
                            'T Nagar',
                            'Velachery',
                            'Adyar',
                            'Tambaram',
                            'Porur',
                            'OMR',
                            'Sholinganallur',
                            'Guindy',
                            'Nungambakkam',
                            'Perungudi',
                            'Ambattur'],
                'Coimbatore': ['RS Puram',
                               'Gandhipuram',
                               'Peelamedu',
                               'Saibaba Colony',
                               'Singanallur',
                               'Saravanampatti',
                               'Avinashi Road'],
                'Madurai': ['Anna Nagar',
                            'KK Nagar',
                            'Tallakulam',
                            'Mattuthavani',
                            'Goripalayam',
                            'Teppakulam'],
                'Tiruchirappalli': ['Srirangam',
                                    'Thillai Nagar',
                                    'Cantonment',
                                    'Woraiyur',
                                    'KK Nagar',
                                    'Thiruverumbur'],
                'Salem': ['Fairlands', 'Hasthampatti', 'Ammapet', 'Five Roads', 'Suramangalam'],
                'Tiruppur': ['Avinashi Road', 'PN Road', 'Palladam Road', 'Kangeyam Road'],
                'Tirunelveli': ['Palayamkottai', 'Vannarpettai', 'Maharaja Nagar', 'NGO Colony'],
                'Erode': ['Perundurai Road', 'Brough Road', 'Sampath Nagar', 'Thindal']},
 'Telangana': {'Hyderabad': ['Gachibowli',
                             'Madhapur',
                             'HITEC City',
                             'Kondapur',
                             'Kukatpally',
                             'Miyapur',
                             'Banjara Hills',
                             'Jubilee Hills',
                             'Ameerpet',
                             'Secunderabad',
                             'LB',
                             'Nagar',
                             'Uppal',
                             'Manikonda',
                             'Nallagandla',
                             'Kompally',
                             'Tellapur',
                             'Narsingi'],
               'Warangal': ['Hanamkonda',
                            'Kazipet',
                            'Subedari',
                            'Nakkalagutta',
                            'Balasamudram',
                            'Waddepally',
                            'Enumamula'],
               'Karimnagar': ['Mankammathota', 'Mukarampura', 'Kothirampur', 'Jyothinagar'],
               'Nizamabad': ['Dichpally', 'Vinayak Nagar', 'Khaleelwadi', 'Bodhan Road'],
               'Khammam': ['Wyra Road', 'Mamillaguda', 'NSP Camp', 'Rotary Nagar'],
               'Nalgonda': ['Devarakonda Road', 'Marriguda', 'Ramagiri', 'Clock Tower'],
               'Mahabubnagar': ['New Town', 'Boyapally', 'Yenugonda', 'Christianpally'],
               'Siddipet': ['Prashanth Nagar', 'Housing Board Colony', 'Ponnala']},
 'Tripura': {'Agartala': ['Banamalipur', 'Dhaleswar', 'Kunjaban', 'Pratapgarh', 'Abhoynagar'],
             'Udaipur': ['Radhakishorepur', 'Netaji Subhash Road', 'East Bank'],
             'Dharmanagar': ['Hospital Road', 'Kalibari Road', 'Rajbari']},
 'Uttar Pradesh': {'Lucknow': ['Gomti Nagar',
                               'Hazratganj',
                               'Aliganj',
                               'Indira Nagar',
                               'Mahanagar',
                               'Jankipuram',
                               'Sushant Golf City',
                               'Alambagh'],
                   'Kanpur': ['Swaroop Nagar',
                              'Kakadeo',
                              'Kidwai Nagar',
                              'Govind Nagar',
                              'Kalyanpur',
                              'Arya Nagar'],
                   'Varanasi': ['Lanka', 'Sigra', 'Bhelupur', 'Mahmoorganj', 'Cantt', 'Shivpur', 'Sarnath'],
                   'Agra': ['Sikandra', 'Sanjay Place', 'Kamla Nagar', 'Tajganj', 'Dayalbagh'],
                   'Prayagraj': ['Civil Lines', 'Naini', 'Jhunsi', 'George Town', 'Lukerganj', 'Kareli'],
                   'Noida': ['Sector 18',
                             'Sector 62',
                             'Sector 50',
                             'Sector 75',
                             'Sector 76',
                             'Sector 137',
                             'Sector 150',
                             'Greater Noida West'],
                   'Ghaziabad': ['Indirapuram',
                                 'Vaishali',
                                 'Vasundhara',
                                 'Raj Nagar',
                                 'Crossings Republik',
                                 'Kaushambi'],
                   'Meerut': ['Shastri Nagar', 'Ganga Nagar', 'Pallavpuram', 'Civil Lines', 'Modipuram'],
                   'Mathura': ['Vrindavan', 'Krishna Nagar', 'Civil Lines', 'Govardhan Road']},
 'Uttarakhand': {'Dehradun': ['Rajpur Road',
                              'Jakhan',
                              'Clement Town',
                              'Sahastradhara Road',
                              'Prem Nagar',
                              'Patel Nagar',
                              'Vasant Vihar'],
                 'Haridwar': ['Jwalapur', 'Ranipur', 'Bhupatwala', 'Shivalik Nagar', 'Kankhal'],
                 'Rishikesh': ['Tapovan', 'Muni Ki Reti', 'Shyampur', 'Nirmal Block'],
                 'Haldwani': ['Mukhani', 'Kathgodam', 'Kusumkhera', 'Rampur Road'],
                 'Roorkee': ['Civil Lines', 'Ramnagar', 'Ganeshpur', 'Solani Puram']},
 'West Bengal': {'Kolkata': ['Salt Lake',
                             'New Town',
                             'Park Street',
                             'Ballygunge',
                             'Tollygunge',
                             'Garia',
                             'Behala',
                             'Dum Dum',
                             'Alipore',
                             'Rajarhat',
                             'Jadavpur'],
                 'Howrah': ['Shibpur', 'Kadamtala', 'Santragachi', 'Liluah', 'Belur'],
                 'Siliguri': ['Sevoke Road', 'Matigara', 'Pradhan Nagar', 'Hill Cart Road', 'Hakimpara'],
                 'Durgapur': ['City Centre', 'Benachity', 'Bidhannagar', 'Muchipara'],
                 'Asansol': ['Burnpur', 'Court More', 'Ushagram', 'Sen Raleigh Road']},
 'Andaman and Nicobar Islands': {'Sri Vijaya Puram (Port Blair)': ['Aberdeen Bazaar',
                                                                   'Junglighat',
                                                                   'Dollygunj',
                                                                   'Garacharma',
                                                                   'Haddo'],
                                 'Diglipur': ['Ramnagar', 'Kalipur', 'Diglipur Bazaar'],
                                 'Car Nicobar': ['Malacca', 'Perka', 'Tamaloo']},
 'Chandigarh': {'Chandigarh': ['Sector 17',
                               'Sector 22',
                               'Sector 35',
                               'Sector 43',
                               'Sector 8',
                               'Sector 15',
                               'Manimajra',
                               'Industrial Area']},
 'Dadra and Nagar Haveli and Daman and Diu': {'Silvassa': ['Tokarkhada', 'Samarvarni', 'Amli', 'Vapi Road'],
                                              'Daman': ['Nani Daman', 'Moti Daman', 'Devka', 'Dunetha'],
                                              'Diu': ['Diu Town', 'Fudam', 'Vanakbara']},
 'Delhi (NCT)': {'New Delhi / Delhi': ['Connaught Place',
                                       'Karol Bagh',
                                       'Lajpat Nagar',
                                       'Saket',
                                       'Hauz Khas',
                                       'Vasant Kunj',
                                       'Dwarka',
                                       'Rohini',
                                       'Janakpuri',
                                       'Pitampura',
                                       'Rajouri',
                                       'Garden',
                                       'Shahdara']},
 'Jammu and Kashmir': {'Srinagar': ['Rajbagh',
                                    'Lal Chowk',
                                    'Hazratbal',
                                    'Nishat',
                                    'Bemina',
                                    'Nowgam',
                                    'Hyderpora'],
                       'Jammu': ['Gandhi Nagar',
                                 'Trikuta Nagar',
                                 'Channi Himmat',
                                 'Talab Tillo',
                                 'Janipur',
                                 'Bahu Plaza'],
                       'Anantnag': ['Lal Chowk', 'KP Road', 'Mattan', 'Bijbehara'],
                       'Baramulla': ['Khanpora', 'Kanthbagh', 'Azad Gunj', 'Delina']},
 'Ladakh': {'Leh': ['Changspa', 'Skara', 'Fort Road', 'Choglamsar', 'Saboo'],
            'Kargil': ['Baroo', 'Trespone', 'Poyen', 'Kurbathang']},
 'Lakshadweep': {'Kavaratti': ['Kavaratti Town', 'Eastern Jetty area', 'Western Jetty area'],
                 'Agatti': ['Agatti village areas'],
                 'Andrott': ['Andrott settlement areas'],
                 'Minicoy': ['Minicoy village areas']},
 'Puducherry': {'Puducherry': ['White Town',
                               'Heritage Town',
                               'Lawspet',
                               'Muthialpet',
                               'Reddiarpalayam',
                               'Mudaliarpet',
                               'Villianur'],
                'Karaikal': ['Karaikal town', 'Neravy', 'Thirunallar'],
                'Mahe': ['Mahe town', 'Palloor', 'Pandakkal'],
                'Yanam': ['Yanam town', 'Mettakur', 'Farampeta']}}

MODEL_CITY_ALIASES = {
    "Bengaluru": "Bangalore",
    "New Delhi / Delhi": "Delhi",
}

# =====================================================
# 3. CUSTOM CSS - PREMIUM ANIMATED UI
# =====================================================

st.markdown("""
<style>

@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap');

.stApp {
background: #F8F6F1;
font-family: 'DM Sans', sans-serif;
color: #292820;
}

/* ANIMATIONS */

@keyframes fadeIn {
from {
opacity: 0;
transform: translateY(20px);
}
to {
opacity: 1;
transform: translateY(0);
}
}

@keyframes slideIn {
from {
opacity: 0;
transform: translateX(-20px);
}
to {
opacity: 1;
transform: translateX(0);
}
}

@keyframes shimmer {
0% { background-position: 0% 50%; }
100% { background-position: 200% 50%; }
}

@keyframes float {
0%, 100% { transform: translateY(0); }
50% { transform: translateY(-5px); }
}

/* MAIN AREA */

.main .block-container {
padding-top: 2rem;
padding-bottom: 3rem;
}

/* SIDEBAR */

[data-testid="stSidebar"] {
background: #25251F;
}

[data-testid="stSidebar"] * {
color: #F5F0E6 !important;
}

[data-testid="stSidebar"] hr {
border-color: #514C3D;
}

/* HEADINGS */

.main-title {
font-family: 'Playfair Display', serif;
font-size: 42px;
font-weight: 700;
color: #292820;
animation: fadeIn 0.8s ease;
}

.subtitle {
color: #817D70;
font-size: 15px;
margin-bottom: 22px;
animation: fadeIn 1s ease;
}

.section-title {
font-family: 'Playfair Display', serif;
font-size: 27px;
font-weight: 700;
color: #292820;
margin-top: 22px;
margin-bottom: 15px;
animation: slideIn 0.7s ease;
}

/* METRIC CARDS */

.metric-card {
background: #FFFFFF;
padding: 24px;
border-radius: 17px;
border: 1px solid #EAE4D8;
box-shadow: 0 5px 18px rgba(0,0,0,0.04);
min-height: 115px;
animation: fadeIn 0.8s ease;
transition: all 0.3s ease;
}

.metric-card:hover {
transform: translateY(-7px);
box-shadow: 0 12px 25px rgba(169,135,73,0.15);
border-color: #C5A467;
}

.metric-label {
font-size: 14px;
color: #817D70;
}

.metric-value {
font-size: 25px;
font-weight: 800;
color: #292820;
margin-top: 12px;
}

/* FEATURE CARDS */

.feature-card {
background: linear-gradient(145deg, #FFFFFF, #F8F4EB);
border: 1px solid #EAE4D8;
padding: 28px;
border-radius: 18px;
min-height: 175px;
animation: fadeIn 1s ease;
transition: all 0.35s ease;
}

.feature-card:hover {
transform: translateY(-7px);
box-shadow: 0 15px 30px rgba(0,0,0,0.08);
}

.feature-card h3 {
color: #292820;
font-size: 22px;
}

.feature-card p {
color: #817D70;
line-height: 1.7;
}

/* HERO CARD */

.hero-card {
background: linear-gradient(
120deg,
#25251F,
#51432B,
#A98749
);
background-size: 200% 200%;
animation: shimmer 8s linear infinite;
border-radius: 20px;
padding: 32px;
color: white;
margin-bottom: 25px;
}

.hero-card h2 {
color: white;
font-family: 'Playfair Display', serif;
font-size: 30px;
}

.hero-card p {
color: #F5EBD7;
}

/* RESULT CARD */

.result-card {
background: linear-gradient(135deg, #D8BD83, #A98749);
border-radius: 20px;
padding: 35px;
text-align: center;
color: white;
animation: fadeIn 1s ease;
box-shadow: 0 10px 30px rgba(169,135,73,0.2);
}

.result-card h2 {
color: white;
}

.result-price {
color: white;
font-size: 43px;
font-weight: 800;
margin: 15px 0;
}

/* INPUT FIELDS */

.stApp label,
[data-testid="stWidgetLabel"] p {
color: #292820 !important;
font-weight: 600 !important;
}

.stTextInput input,
.stNumberInput input {
background: white !important;
color: #292820 !important;
border: 1px solid #DED5C5 !important;
border-radius: 10px !important;
}

.stSelectbox [data-baseweb="select"] > div {
background: white !important;
color: #292820 !important;
border-radius: 10px !important;
}

/* BUTTONS */

div.stButton > button,
.stFormSubmitButton button {
background: linear-gradient(135deg, #B99654, #A98749) !important;
color: white !important;
border: none !important;
border-radius: 10px !important;
font-weight: 700 !important;
padding: 12px 20px !important;
transition: all 0.3s ease;
}

div.stButton > button:hover,
.stFormSubmitButton button:hover {
transform: translateY(-3px);
box-shadow: 0 8px 18px rgba(169,135,73,0.3);
}

/* ALERTS */

[data-testid="stAlert"] {
border-radius: 12px;
}

/* TABLES */

[data-testid="stDataFrame"] {
border-radius: 12px;
}

/* RESPONSIVE */

@media(max-width: 768px) {
.main-title {
font-size: 30px;
}

.result-price {
font-size: 30px;
}
}

</style>""", unsafe_allow_html=True)


# =====================================================
# 4. MACHINE LEARNING MODEL
# =====================================================

@st.cache_resource
def load_model():

    saved_model = joblib.load("house_price_model.pkl")

    return saved_model["model"], saved_model["columns"]


try:

    model, model_columns = load_model()

    model_loaded = True

except Exception as e:

    model_loaded = False

    st.error(f"Model loading error: {e}")


# =====================================================
# 5. MONGODB CONNECTION
# =====================================================

@st.cache_resource
def initialize_database():

    return connect_database()


database_connected = initialize_database()


# =====================================================
# 6. HELPER FUNCTIONS
# =====================================================

def format_price(price):

    if price >= 10000000:
        return f"₹{price / 10000000:.2f} Crore"

    elif price >= 100000:
        return f"₹{price / 100000:.2f} Lakh"

    return f"₹{price:,.0f}"


def create_metric(title, value, icon):

    html_content = f"""
<div class="metric-card">

<div style="font-size:27px;margin-bottom:10px;">
{icon}
</div>

<div class="metric-label">
{title}
</div>

<div class="metric-value">
{value}
</div>

</div>"""

    st.markdown(html_content, unsafe_allow_html=True)


def create_feature(title, description, icon):

    html_content = f"""
<div class="feature-card">

<h3>{icon} {title}</h3>

<p>{description}</p>

</div>"""

    st.markdown(html_content, unsafe_allow_html=True)


# =====================================================
# 7. SIDEBAR
# =====================================================

pages = [
    "Dashboard",
    "Price Prediction",
    "Market Analysis",
    "Prediction History",
    "About Project"
]

# Keep navigation state separate from Streamlit's radio widget state.
# Dashboard buttons update the radio value through callbacks, before rerun.
def navigate_to(page_name):
    st.session_state.page_selector = page_name


if "page_selector" not in st.session_state:
    st.session_state.page_selector = "Dashboard"


with st.sidebar:

    st.markdown("""
<h1 style="
font-family:Playfair Display;
color:#D8BD83;
font-size:29px;
">
🏡 SmartHome AI
</h1>

<p style="color:#C8BEAA;">
Intelligent Property Valuation
</p>
""", unsafe_allow_html=True)

    st.markdown("---")

    st.markdown(
        "<p style='color:#D8BD83;font-weight:700;'>MAIN MENU</p>",
        unsafe_allow_html=True
    )

    page = st.radio(
        "NAVIGATION",
        pages,
        key="page_selector",
        label_visibility="collapsed"
    )

    st.markdown("---")

    if database_connected:

        st.success("● Database Connected")

    else:

        st.error("● Database Disconnected")

    st.markdown("""
<br>

<div style="
background:#35352C;
padding:15px;
border-radius:12px;
">

<p style="color:#D8BD83;font-weight:700;">
SmartHome AI
</p>

<p style="font-size:12px;">
Indian House Price Prediction
</p>

<p style="font-size:11px;">
Powered by Machine Learning
</p>

</div>
""", unsafe_allow_html=True)


# =====================================================
# 8. DATABASE RECORDS
# =====================================================

records = get_predictions() if database_connected else []

history_df = pd.DataFrame(records)


# =====================================================
# 9. DASHBOARD
# =====================================================

if page == "Dashboard":

    st.markdown(
        '<div class="main-title">Welcome to SmartHome AI 👋</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="subtitle">Your intelligent property valuation dashboard.</div>',
        unsafe_allow_html=True
    )

    st.markdown("""
<div class="hero-card">

<h2>Find Your Dream Home 🏡</h2>

<p>
Discover property values, explore different localities
and make smarter real-estate decisions.
</p>

</div>""", unsafe_allow_html=True)

    total = len(history_df)

    if total > 0:

        average = history_df["predicted_price"].mean()

        highest = history_df["predicted_price"].max()

    else:

        average = 0

        highest = 0

    st.markdown(
        '<div class="section-title">Dashboard Overview</div>',
        unsafe_allow_html=True
    )

    c1, c2, c3, c4 = st.columns(4)

    with c1:

        create_metric(
            "Total Predictions",
            str(total),
            "📊"
        )

    with c2:

        create_metric(
            "Average Price",
            format_price(average),
            "💰"
        )

    with c3:

        create_metric(
            "Highest Prediction",
            format_price(highest),
            "🏆"
        )

    with c4:

        create_metric(
            "Model R² Score",
            "0.99",
            "🤖"
        )

    st.markdown(
        '<div class="section-title">Explore SmartHome AI</div>',
        unsafe_allow_html=True
    )

    c1, c2 = st.columns(2)

    with c1:

        create_feature(
            "Property Valuation",
            "Estimate your property value using machine learning "
            "and locality-based market adjustments.",
            "🏠"
        )

        st.button(
            "Explore Price Prediction →",
            use_container_width=True,
            on_click=navigate_to,
            args=("Price Prediction",)
        )

    with c2:

        create_feature(
            "Market Insights",
            "Explore city-wise and locality-wise property prices "
            "with interactive charts.",
            "📈"
        )

        st.button(
            "Explore Market →",
            use_container_width=True,
            on_click=navigate_to,
            args=("Market Analysis",)
        )

    st.markdown(
        '<div class="section-title">Recent Activity</div>',
        unsafe_allow_html=True
    )

    if total > 0:

        recent = history_df.copy()

        if "created_at" in recent.columns:

            recent["created_at"] = pd.to_datetime(
                recent["created_at"],
                errors="coerce"
            )

        columns = [
            c for c in [
                "state",
                "city",
                "locality",
                "area",
                "predicted_price",
                "created_at"
            ]
            if c in recent.columns
        ]

        st.dataframe(
            recent[columns].head(5),
            use_container_width=True,
            hide_index=True
        )

    else:

        st.info("Your recent property predictions will appear here.")


# =====================================================
# 10. PRICE PREDICTION
# =====================================================

elif page == "Price Prediction":

    st.markdown(
        '<div class="main-title">Property Price Estimator 🏡</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="subtitle">Find the estimated value of your dream property.</div>',
        unsafe_allow_html=True
    )

    st.markdown("""
<div class="hero-card">

<h2>Smart Property Valuation</h2>

<p>
Enter your property details and select its locality
to receive an estimated property value.
</p>

</div>""", unsafe_allow_html=True)

    st.markdown(
        '<div class="section-title">📍 Location Information</div>',
        unsafe_allow_html=True
    )

    # State -> City -> Locality selectors are outside the form so each
    # selection refreshes the dependent dropdown immediately.
    state_options = list(INDIA_LOCATION_DATA.keys())
    location_col1, location_col2, location_col3 = st.columns(3)

    with location_col1:
        selected_state = st.selectbox(
            "Select State / Union Territory",
            state_options,
            key="prediction_state"
        )

    city_options = list(INDIA_LOCATION_DATA[selected_state].keys())
    with location_col2:
        city = st.selectbox(
            "Select City / Town",
            city_options,
            key=f"prediction_city_{selected_state}"
        )

    locality_options = INDIA_LOCATION_DATA[selected_state][city]
    with location_col3:
        locality = st.selectbox(
            "Select Locality",
            locality_options,
            key=f"prediction_locality_{selected_state}_{city}"
        )

    # Verified/indicative price benchmarks currently exist only for the
    # original five cities. Other directory locations remain selectable,
    # but their ML estimate is not adjusted using invented locality prices.
    market_city_alias = MODEL_CITY_ALIASES.get(city, city)
    benchmark_city = market_city_alias if market_city_alias in CITY_LOCALITY_PRICES else None
    locality_rate = (
        CITY_LOCALITY_PRICES.get(benchmark_city, {}).get(locality)
        if benchmark_city else None
    )
    city_average = CITY_AVERAGES.get(benchmark_city) if benchmark_city else None

    if locality_rate is not None and city_average:
        st.info(
            f"📍 {locality}, {city}: indicative benchmark ₹{locality_rate:,} per sq. ft. "
            f"(city average: ₹{city_average:,}/sq. ft.)"
        )
    else:
        st.info(
            f"📍 Selected location: {locality}, {city}, {selected_state}. "
            "Location is available in the directory; a reliable locality price benchmark "
            "is not currently configured, so no locality price adjustment will be applied."
        )

    model_city_for_check = MODEL_CITY_ALIASES.get(city, city)
    if model_city_for_check not in CITY_AVERAGES:
        st.caption(
            "Model coverage note: this city is not among the five benchmark cities "
            "currently configured in this project. The estimate will not receive a "
            "city/locality price adjustment and should be treated as indicative."
        )

    with st.form("prediction_form"):
        st.markdown(
            '<div class="section-title">🏠 Property Information</div>',
            unsafe_allow_html=True
        )

        col1, col2 = st.columns(2)

        with col1:
            area = st.number_input(
                "Property Area (sq. ft.)",
                min_value=300,
                max_value=10000,
                value=1500
            )

            bedrooms = st.selectbox(
                "Number of Bedrooms",
                [1, 2, 3, 4, 5]
            )

            bathrooms = st.selectbox(
                "Number of Bathrooms",
                [1, 2, 3, 4, 5]
            )

        with col2:
            floors = st.selectbox(
                "Number of Floors",
                [1, 2, 3, 4]
            )

            property_age = st.number_input(
                "Property Age (Years)",
                min_value=0,
                max_value=100,
                value=5
            )

            parking = st.selectbox(
                "Parking Spaces",
                [0, 1, 2, 3]
            )

        st.write("")
        submitted = st.form_submit_button(
            "✨ Calculate Property Value",
            use_container_width=True
        )

    # ================================================
    # PREDICTION CALCULATION
    # ================================================

    if submitted:

        if not model_loaded:

            st.error("Machine Learning model is unavailable.")

        elif not database_connected:

            st.error("MongoDB connection is unavailable.")

        else:

            input_data = pd.DataFrame([{

                "city": MODEL_CITY_ALIASES.get(city, city),

                "area": area,

                "bedrooms": bedrooms,

                "bathrooms": bathrooms,

                "floors": floors,

                "property_age": property_age,

                "parking": parking

            }])

            input_data = pd.get_dummies(
                input_data,
                columns=["city"]
            )

            input_data = input_data.reindex(
                columns=model_columns,
                fill_value=0
            )

            ml_price = float(
                model.predict(input_data)[0]
            )

            ml_price = max(0, ml_price)

            # CITY-WISE LOCALITY ADJUSTMENT
            # Compare the selected locality benchmark with that city's average.
            locality_factor = (
                locality_rate / city_average
                if locality_rate is not None and city_average
                else 1.0
            )
            predicted_price = ml_price * locality_factor

            predicted_price = max(0, predicted_price)

            price_per_sqft = predicted_price / area

            market_reference = (
                area * locality_rate
                if locality_rate is not None
                else None
            )

            prediction_record = {

                "state": selected_state,

                "city": city,

                "locality": locality,

                "area": int(area),

                "bedrooms": int(bedrooms),

                "bathrooms": int(bathrooms),

                "floors": int(floors),

                "property_age": int(property_age),

                "parking": int(parking),

                "ml_base_price": ml_price,

                "locality_factor": locality_factor,

                "locality_rate": locality_rate,

                "predicted_price": predicted_price,

                "price_per_sqft": price_per_sqft,

                "created_at": datetime.now(),

                "currency": "INR"

            }

            saved_id = save_prediction(
                prediction_record
            )

            st.write("")

            st.markdown(f"""
<div class="result-card">

<h2>✨ Estimated Property Value</h2>

<div class="result-price">
{format_price(predicted_price)}
</div>

<p>
📍 {html.escape(locality)}, {html.escape(city)}, {html.escape(selected_state)}
</p>

<p>
Your estimated property valuation
</p>

</div>""", unsafe_allow_html=True)

            st.markdown(
                '<div class="section-title">Property Summary</div>',
                unsafe_allow_html=True
            )

            c1, c2, c3 = st.columns(3)

            with c1:

                create_metric(
                    "Property Area",
                    f"{area:,} sq. ft.",
                    "📐"
                )

            with c2:

                create_metric(
                    "Price Per Sq. Ft.",
                    f"₹{price_per_sqft:,.0f}",
                    "💰"
                )

            with c3:

                create_metric(
                    "Bedrooms",
                    str(bedrooms),
                    "🛏️"
                )

            if locality_rate is not None:

                st.markdown(
                    '<div class="section-title">Locality Market Insights</div>',
                    unsafe_allow_html=True
                )

                c1, c2 = st.columns(2)

                with c1:

                    create_metric(
                        "Locality Benchmark",
                        f"₹{locality_rate:,}/sq.ft.",
                        "📍"
                    )

                with c2:

                    create_metric(
                        "Area-Based Market Reference",
                        format_price(market_reference),
                        "🏘️"
                    )

                st.caption(
                    "The market reference is calculated using the "
                    "indicative locality asking price multiplied by "
                    "your property area. It is not a verified sale quote."
                )

            if saved_id:

                st.success(
                    "✅ Prediction successfully saved in MongoDB!"
                )

            else:

                st.error(
                    "Prediction generated, but database saving failed."
                )

            st.warning(
                "This is an educational hybrid estimate. The locality "
                "adjustment uses indicative asking-price benchmarks; "
                "it is not an independently trained locality model."
            )


# =====================================================
# 11. MARKET ANALYSIS
# =====================================================

elif page == "Market Analysis":

    st.markdown(
        '<div class="main-title">Real Estate Market Insights 📊</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="subtitle">Explore property prices across cities and their localities.</div>',
        unsafe_allow_html=True
    )

    # INDIA-WIDE LOCATION DIRECTORY + PRICE BENCHMARK VIEW
    market_col1, market_col2, market_col3 = st.columns(3)

    with market_col1:
        market_state = st.selectbox(
            "Select State / Union Territory",
            list(INDIA_LOCATION_DATA.keys()),
            key="market_state_filter"
        )

    with market_col2:
        market_city_options = list(INDIA_LOCATION_DATA[market_state].keys())
        selected_market_city = st.selectbox(
            "Select City / Town",
            market_city_options,
            key=f"market_city_{market_state}"
        )

    with market_col3:
        market_localities = INDIA_LOCATION_DATA[market_state][selected_market_city]
        selected_market_locality = st.selectbox(
            "Select Locality",
            market_localities,
            key=f"market_locality_{market_state}_{selected_market_city}"
        )

    st.markdown(
        f'<div class="section-title">{html.escape(selected_market_city)} Locality Information</div>',
        unsafe_allow_html=True
    )

    market_benchmark_city = MODEL_CITY_ALIASES.get(selected_market_city, selected_market_city)
    market_rates = CITY_LOCALITY_PRICES.get(market_benchmark_city, {})
    if market_rates:
        locality_df = pd.DataFrame({
            "Locality": list(market_rates.keys()),
            "Price per sq. ft. (₹)": list(market_rates.values())
        }).sort_values("Price per sq. ft. (₹)", ascending=False)

        fig = px.bar(
            locality_df,
            x="Locality",
            y="Price per sq. ft. (₹)",
            color="Price per sq. ft. (₹)",
            color_continuous_scale=["#E8D9B7", "#A98749"],
            title=f"Indicative Property Price by {selected_market_city} Locality"
        )
        fig.update_layout(
            template="plotly_white", plot_bgcolor="#FFFFFF", paper_bgcolor="#F8F6F1",
            font=dict(color="#292820", family="Arial", size=13),
            title=dict(font=dict(color="#292820", size=19)),
            xaxis=dict(title=dict(text="Locality", font=dict(color="#292820", size=14)),
                       tickfont=dict(color="#292820", size=12), tickangle=-45, showgrid=False),
            yaxis=dict(title=dict(text="Price per sq. ft. (₹)", font=dict(color="#292820", size=14)),
                       tickfont=dict(color="#292820", size=12), gridcolor="#E7E0D5"),
            coloraxis_colorbar=dict(title=dict(text="₹ / sq. ft.", font=dict(color="#292820")),
                                    tickfont=dict(color="#292820")),
            margin=dict(l=25, r=25, t=65, b=100)
        )
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(locality_df, use_container_width=True, hide_index=True)
        if selected_market_locality in market_rates:
            st.metric("Selected locality benchmark", f"₹{market_rates[selected_market_locality]:,} / sq. ft.")
    else:
        st.info(
            f"{selected_market_city}, {market_state} is included in the India location directory. "
            "Localities are available for selection, but verified locality-wise price data "
            "has not yet been added. No price chart is shown to avoid inventing market values."
        )
        st.write("**Localities in this city:**")
        st.write(", ".join(market_localities))

    st.caption(
        "Locality benchmarks are indicative listing/asking-price references. "
        "Actual prices vary by property type, project, age, floor, amenities and negotiation."
    )

    st.markdown("---")

    # CITY-WISE CHART

    st.markdown(
        '<div class="section-title">City-Wise Property Comparison</div>',
        unsafe_allow_html=True
    )

    try:

        data = pd.read_csv("house_data.csv")

        city_data = (
            data.groupby("city")["price"]
            .mean()
            .reset_index()
        )

        city_data["price_lakh"] = (
            city_data["price"] / 100000
        )

        fig2 = px.bar(

            city_data,

            x="city",

            y="price_lakh",

            color="price_lakh",

            color_continuous_scale=[
                "#E8D9B7",
                "#A98749"
            ],

            title="Average House Price by City"

        )

        fig2.update_layout(
            template="plotly_white",
            plot_bgcolor="#FFFFFF",
            paper_bgcolor="#F8F6F1",
            font=dict(color="#292820", family="Arial", size=13),
            title=dict(font=dict(color="#292820", size=19)),
            xaxis=dict(
                title=dict(text="City", font=dict(color="#292820", size=14)),
                tickfont=dict(color="#292820", size=13),
                showgrid=False,
                zeroline=False
            ),
            yaxis=dict(
                title=dict(text="Average Price (₹ Lakhs)", font=dict(color="#292820", size=14)),
                tickfont=dict(color="#292820", size=12),
                gridcolor="#E7E0D5",
                zeroline=False
            ),
            coloraxis_colorbar=dict(
                title=dict(text="Average price (₹ Lakhs)", font=dict(color="#292820")),
                tickfont=dict(color="#292820")
            ),
            margin=dict(l=25, r=35, t=65, b=55)
        )

        st.plotly_chart(
            fig2,
            use_container_width=True
        )

        fig3 = px.scatter(

            data,

            x="area",

            y="price",

            color="city",

            title="Property Area vs House Price"

        )

        fig3.update_layout(
            template="plotly_white",
            plot_bgcolor="#FFFFFF",
            paper_bgcolor="#F8F6F1",
            font=dict(color="#292820", family="Arial", size=13),
            title=dict(font=dict(color="#292820", size=19)),
            xaxis=dict(
                title=dict(text="Property Area (sq. ft.)", font=dict(color="#292820", size=14)),
                tickfont=dict(color="#292820", size=12),
                gridcolor="#E7E0D5"
            ),
            yaxis=dict(
                title=dict(text="Property Price (₹)", font=dict(color="#292820", size=14)),
                tickfont=dict(color="#292820", size=12),
                gridcolor="#E7E0D5"
            ),
            legend=dict(
                title=dict(font=dict(color="#292820")),
                font=dict(color="#292820", size=12),
                bgcolor="rgba(255,255,255,0.85)"
            ),
            margin=dict(l=25, r=25, t=65, b=55)
        )

        st.plotly_chart(
            fig3,
            use_container_width=True
        )

    except Exception as e:

        st.error(
            f"Unable to load city market data: {e}"
        )


# =====================================================
# 12. PREDICTION HISTORY
# =====================================================

elif page == "Prediction History":

    st.markdown(
        '<div class="main-title">Prediction History 📜</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="subtitle">View, search and manage your saved property predictions.</div>',
        unsafe_allow_html=True
    )

    if not database_connected:

        st.error("MongoDB connection unavailable.")

    elif history_df.empty:

        st.info("No prediction records available yet.")

    else:

        filtered = history_df.copy()

        search = st.text_input(
            "🔍 Search by city or locality"
        )

        if search:

            mask = (
                filtered["city"].astype(str).str.contains(
                    search,
                    case=False,
                    na=False
                )
            )

            if "locality" in filtered.columns:

                mask |= filtered["locality"].astype(
                    str
                ).str.contains(
                    search,
                    case=False,
                    na=False
                )

            filtered = filtered[mask]

        if "created_at" in filtered.columns:

            filtered["created_at"] = pd.to_datetime(
                filtered["created_at"],
                errors="coerce"
            )

        st.markdown(
            '<div class="section-title">Saved Predictions</div>',
            unsafe_allow_html=True
        )

        display_columns = [

            col for col in [

                "city",

                "locality",

                "area",

                "predicted_price",

                "created_at"

            ]

            if col in filtered.columns

        ]

        display_df = filtered[display_columns].copy()

        if "predicted_price" in display_df.columns:

            display_df["predicted_price"] = display_df[
                "predicted_price"
            ].apply(format_price)

        st.dataframe(

            display_df,

            use_container_width=True,

            hide_index=True

        )

        csv_data = filtered.drop(

            columns=["_id"],

            errors="ignore"

        ).to_csv(index=False)

        st.download_button(

            "📥 Download Prediction History",

            data=csv_data,

            file_name="SmartHome_Predictions.csv",

            mime="text/csv"

        )

        st.markdown("---")

        st.markdown(
            '<div class="section-title">Delete Prediction</div>',
            unsafe_allow_html=True
        )

        options = {

            f"{r['city']} - {r.get('locality', 'N/A')} - "
            f"{format_price(r['predicted_price'])} - {r['_id']}":

            r["_id"]

            for r in records

        }

        if options:

            selected = st.selectbox(

                "Select prediction",

                list(options.keys())

            )

            if st.button("🗑️ Delete Selected Prediction"):

                if delete_prediction(options[selected]):

                    st.success(
                        "Prediction deleted successfully!"
                    )

                    st.rerun()

                else:

                    st.error(
                        "Unable to delete prediction."
                    )


# =====================================================
# 13. ABOUT PROJECT
# =====================================================

elif page == "About Project":

    st.markdown(
        '<div class="main-title">About SmartHome AI</div>',
        unsafe_allow_html=True
    )

    st.markdown("""
<div class="hero-card">

<h2>🏡 SmartHome AI</h2>

<p>
An intelligent Indian House Price Prediction
and Property Valuation System.
</p>

</div>""", unsafe_allow_html=True)

    create_feature(
        "Machine Learning",
        "Predicts property prices using a trained regression model.",
        "🤖"
    )

    create_feature(
        "Locality Intelligence",
        "Provides State → City → Locality selection across the supplied India directory; "
        "uses price benchmarks only where configured.",
        "📍"
    )

    create_feature(
        "MongoDB Database",
        "Stores property predictions and maintains prediction history.",
        "🗄️"
    )

    create_feature(
        "Interactive Analytics",
        "Visualizes property prices using interactive charts.",
        "📊"
    )

    st.markdown("""
<div class="hero-banner">
<h2>Find Your Dream Home 🏡</h2>
<p>
Discover property values, explore different localities
and make smarter real-estate decisions.
</p>
</div>""", unsafe_allow_html=True)

    technologies = pd.DataFrame({

        "Technology": [

            "Python",

            "Streamlit",

            "Scikit-learn",

            "MongoDB",

            "Pandas",

            "Plotly"

        ],

        "Purpose": [

            "Programming Language",

            "Frontend Framework",

            "Machine Learning",

            "Database",

            "Data Processing",

            "Data Visualization"

        ]

    })

    st.dataframe(
        technologies,
        use_container_width=True,
        hide_index=True
    )

    st.warning(
        "Disclaimer: This application is an educational project. "
        "Predictions are approximate estimates and should not be "
        "used as professional property valuations."
    )

    st.caption(
        "SmartHome AI | College Mini Project | 2026"
    )


# =====================================================
# END OF APPLICATION
# =====================================================