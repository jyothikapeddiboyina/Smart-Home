import pandas as pd
import numpy as np

np.random.seed(42)

cities = {
    "Hyderabad": 5500,
    "Bangalore": 6500,
    "Chennai": 5000,
    "Mumbai": 12000,
    "Delhi": 7000
}

data = []

for i in range(1000):

    city = np.random.choice(list(cities.keys()))

    area = np.random.randint(500, 3001)

    bedrooms = max(1, min(5, area // 450))

    bathrooms = max(1, bedrooms - 1)

    floors = np.random.randint(1, 5)

    property_age = np.random.randint(0, 31)

    parking = np.random.randint(0, 3)

    base_rate = cities[city]

    price = (
        area * base_rate
        + bedrooms * 250000
        + bathrooms * 150000
        + floors * 50000
        + parking * 200000
    )

    price *= (1 - min(property_age * 0.005, 0.20))

    noise = np.random.uniform(0.95, 1.05)

    price = price * noise

    data.append([
        city,
        area,
        bedrooms,
        bathrooms,
        floors,
        property_age,
        parking,
        int(price)
    ])

df = pd.DataFrame(
    data,
    columns=[
        "city",
        "area",
        "bedrooms",
        "bathrooms",
        "floors",
        "property_age",
        "parking",
        "price"
    ]
)

df.to_csv("house_data.csv", index=False)

print("Dataset generated successfully!")
print("Total records:", len(df))
print(df.head())