import os
from datetime import datetime, timezone

import streamlit as st
from pymongo import MongoClient
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# MongoDB connection
MONGO_URI = os.getenv("MONGO_URI")

client = None
db = None
predictions_collection = None


def connect_database():

    global client, db, predictions_collection

    try:
        if not MONGO_URI:
            raise ValueError("MongoDB URI not found in .env file")

        client = MongoClient(
            MONGO_URI,
            serverSelectionTimeoutMS=5000
        )

        # Test connection
        client.admin.command("ping")

        # Select database
        db = client["SmartHomeDB"]

        # Select collection
        predictions_collection = db["predictions"]

        return True

    except Exception as e:
        print("MongoDB Connection Error:", e)
        return False


def save_prediction(data):

    try:
        if predictions_collection is None:
            if not connect_database():
                return False

        data["created_at"] = datetime.now(timezone.utc)

        result = predictions_collection.insert_one(data)

        return str(result.inserted_id)

    except Exception as e:
        print("Error saving prediction:", e)
        return False


def get_predictions():

    try:
        if predictions_collection is None:
            if not connect_database():
                return []

        records = list(
            predictions_collection.find().sort(
                "created_at", -1
            )
        )

        for record in records:
            record["_id"] = str(record["_id"])

        return records

    except Exception as e:
        print("Error retrieving predictions:", e)
        return []


def delete_prediction(record_id):

    try:
        from bson import ObjectId

        if predictions_collection is None:
            if not connect_database():
                return False

        result = predictions_collection.delete_one(
            {"_id": ObjectId(record_id)}
        )

        return result.deleted_count > 0

    except Exception as e:
        print("Error deleting prediction:", e)
        return False