import pandas as pd
import joblib

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

# Load dataset
data = pd.read_csv("house_data.csv")

# Select input features
X = data[
    [
        "city",
        "area",
        "bedrooms",
        "bathrooms",
        "floors",
        "property_age",
        "parking"
    ]
]

# Convert city names into numerical features
X = pd.get_dummies(X, columns=["city"])

# Target variable
y = data["price"]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Train Random Forest model
model = RandomForestRegressor(
    n_estimators=100,
    random_state=42
)

model.fit(X_train, y_train)

# Evaluate model
predictions = model.predict(X_test)

mae = mean_absolute_error(y_test, predictions)
r2 = r2_score(y_test, predictions)

print("MODEL TRAINING COMPLETED")
print("-------------------------")
print("Mean Absolute Error:", round(mae, 2))
print("R2 Score:", round(r2, 2))

# Save model and feature columns
joblib.dump(
    {
        "model": model,
        "columns": X.columns.tolist()
    },
    "house_price_model.pkl"
)

print("Model saved successfully!")