from database import connect_database

print("Testing MongoDB Connection...")

if connect_database():
    print("MongoDB Connected Successfully!")
    print("Database: SmartHomeDB")
    print("Collection: predictions")
else:
    print("MongoDB Connection Failed!")